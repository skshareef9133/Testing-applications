import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AmazonUrlTest {
    public static void main(String[] args) {

        System.setProperty("webdriver.chrome.driver", "PATH_TO_CHROMEDRIVER");

        WebDriver driver = new ChromeDriver();

        driver.get("https://www.amazon.in/");

        String webPageUrl = driver.getCurrentUrl();

        System.out.println(webPageUrl);

        driver.quit();
    }
}
