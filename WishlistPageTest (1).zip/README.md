In this exercise, you will be automating the process of testing the Color Picker page.

### Prerequisites

- Install IntelliJ IDEA Community IDE  Version 2018.3.6.
- Install OpenJDK 11 and complete the configuration.
- Install a Browser Driver(Chrome Driver).
- Setup a Selenium project with the name `WishlistPageTest`.

You can refer to this [Reading Material](https://learning.ccbp.in/qa-automation-testing/course?c_id=cf952b35-27ab-4b1e-a6de-44227f22806c&s_id=f5c19277-3889-4e63-b631-c06c088d612c&t_id=6a935df7-2c93-477c-b505-3ae0aabcf9a2#31-installing-ide) to complete the above prerequisites.

### Steps to Automate

- Create a driver instance using WebDriver interface.
- Navigate to the url `https://qaecomwishlist.ccbp.tech/`
- Verify the initial state of the page.
  - Checkboxes
    - Expected checkboxes that are selected: `2`
    - If the actual and expected number of checked checkboxes are the same, then print "Selected Checkboxes Matched".
    - Else, print "Selected Checkboxes Mismatched"
  - Buttons
    - Expected buttons that are enabled: `3`
    - If the actual and expected number of enabled buttons are the same, then print "Enabled Buttons Matched".
    - Else, print "Enabled Buttons Mismatched"
- Click all the enabled buttons.
- Verify the selected checkboxes.
  - Expected checkboxes that are selected: `5`
    - If the actual and expected number of checked checkboxes are the same, then print "Selected Checkboxes Matched".
    - Else, print "Selected Checkboxes Mismatched"
- Verify the disabled buttons.
  - Expected buttons that are disabled: `5`
  - If the actual and expected number of disabled buttons are the same, then print "Disabled Buttons Matched".
  - Else, print "Disabled Buttons Mismatched"
- Refresh the page
- Verify the state of the page after refreshing
  - Checkboxes
    - Expected checkboxes that are selected: `2`
    - If the actual and expected number of checked checkboxes are the same, then print "Selected Checkboxes Matched after Refresh".
    - Else, print "Selected Checkboxes Mismatched after Refresh"
  - Buttons
    - Expected buttons that are enabled: `3`
    - If the actual and expected number of enabled buttons are the same, then print "Enabled Buttons Matched after Refresh".
    - Else, print "Enabled Buttons Mismatched after Refresh"
   
- Close the browser window.

<br>
<br>

**Note: Set up the project and practice this exercise in your local IDE(IntelliJ).**