import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.List;

public class PatientsListPageTest {
    public static void main(String[] args) {

        System.setProperty("webdriver.chrome.driver", "PATH_TO_CHROMEDRIVER");

        WebDriver driver = new ChromeDriver();

        driver.get("https://qapatientslist.ccbp.tech/");

        boolean flag = true;

        WebElement smithElement = driver.findElement(By.xpath("//li[starts-with(text(), 'J') and contains(text(), 'Smith')]"));
        String expectedName = "Jane Smith";
        if(!expectedName.equals(smithElement.getText())) {
            System.out.println("Patient Name not Matched");
            flag = false;
        }

        List<WebElement> thirdInOutPatients = driver.findElements(By.xpath("//section[@id = 'outpatients' or @id = 'inpatients']//li[3]"));
        String expectedNames1[] = {"Michael Johnson", "Ash Campbell"};
        for(int i = 0; i < 2; i++) {
            WebElement element = thirdInOutPatients.get(i);
            if(!expectedNames1[i].equals(element.getText())) {
                System.out.println("Third Patient Names in the List Not Matched");
                flag = false;
            }
        }

        List<WebElement> notEmergency = driver.findElements(By.xpath("//section[not(@id = 'emergency')]//li"));
        String expectedNames2[] = {"John Doe", "Jane Smith", "Michael Johnson", "Richardson", "David Smith", "Alvan Peterson", "William Clark", "Ash Campbell", "Alexander Davis", "Asher Wood"};
        for(int i = 0; i < 2; i++) {
            WebElement element = notEmergency.get(i);
            if(!expectedNames2[i].equals(element.getText())) {
                System.out.println("Non Emergency Patient Names not Matched");
                flag = false;
            }
        }

        if(flag){
            System.out.println("All Patient Names Matched");
        }

        driver.quit();
    }
}