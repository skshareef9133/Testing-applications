In this exercise, you will be automating the process of testing the IOT page.

### Prerequisites

- Install IntelliJ IDEA Community IDE  Version 2018.3.6.
- Install OpenJDK 11 and complete the configuration.
- Install a Browser Driver(Chrome Driver).
- Setup a Selenium project with the name `IOTPageTest`.

You can refer to this [Reading Material](https://learning.ccbp.in/qa-automation-testing/course?c_id=cf952b35-27ab-4b1e-a6de-44227f22806c&s_id=f5c19277-3889-4e63-b631-c06c088d612c&t_id=6a935df7-2c93-477c-b505-3ae0aabcf9a2#31-installing-ide) to complete the above prerequisites.

### Steps to Automate

- Create a driver instance using WebDriver interface.
- Navigate to the URL `https://qaiotlorawan.ccbp.tech/`
- Print the Heading text.
- Perform the following actions in the `<iframe>` element - _use name attribute to switch_,
    - Print the Heading text of the embedded Home page.
    - Click the "Know more" button.
    - Wait and Verify the Video title of the embedded video element - _use WebElement to switch_,
        - Expected text: `The Things Conference India 2019 | After Movie`
        - If the video title matches the expected text, print "Video title matched".
        - Else, print "Mismatch found in the video title".
    - Verify the Heading text of the embedded Details page.
        - Expected text: `The Things Conference`
        - If the video title matches the expected text, print "Heading matched".
        - Else, print "Mismatch found in the heading".
- Close the browser window.

<br>
<br>

**Note: Set up the project and practice this exercise in your local IDE(IntelliJ).**