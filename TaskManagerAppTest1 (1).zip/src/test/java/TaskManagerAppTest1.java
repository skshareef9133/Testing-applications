import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import java.util.List;

public class TaskManagerAppTest1 {
    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver", "PATH_TO_CHROMEDRIVER");

        WebDriver driver = new ChromeDriver();

        driver.get("https://qataskmanager.ccbp.tech/");

        List<WebElement> taskElements = driver.findElements(By.className("task"));

        Actions action = new Actions(driver);

        for (WebElement taskElement : taskElements) {
            String originalColor = taskElement.getCssValue("background-color");

            action.moveToElement(taskElement).perform();

            String newColor = taskElement.getCssValue("background-color");

            if(!originalColor.equals(newColor)){
                System.out.println("Background color changed on hover.");
            }else{
                System.out.println("Background color did not change on hover.");
            }
        }

        driver.quit();
    }
}