In this exercise, you will be automating the process of testing the Color Picker page.

### Prerequisites

- Install IntelliJ IDEA Community IDE  Version 2018.3.6.
- Install OpenJDK 11 and complete the configuration.
- Install a Browser Driver(Chrome Driver).
- Setup a Selenium project with the name `ColorPickerPageTest`.

You can refer to this [Reading Material](https://learning.ccbp.in/qa-automation-testing/course?c_id=cf952b35-27ab-4b1e-a6de-44227f22806c&s_id=f5c19277-3889-4e63-b631-c06c088d612c&t_id=6a935df7-2c93-477c-b505-3ae0aabcf9a2#31-installing-ide) to complete the above prerequisites.

### Steps to Automate

- Create a driver instance using WebDriver interface.
- Navigate to the url `https://qacolorpicker.ccbp.tech/`
- Verify the Color Picker Page heading text and font size.
  - Heading text:
    - Expected text: `Color Picker`
    - If the actual heading text and expected text are the same, then print "Heading Checked"
    - Else, print "Heading Mismatched"
  - Font size:
    - Expected font size: `50px`
    - If the actual font size and expected font size are the same, then print "Heading Font Size Checked"
    - Else, print "Heading Font Size Mismatched"
- Verify if all the four Color Buttons background color (RGBA) matches with their corresponding button texts (Hexcode) - _use getCssValue() method_

     | Color Hex Code | RGBA                   |
     | -------------- | ---------------------- |
     | #e0e0e0        | rgba(224, 224, 224, 1) |
     | #6fcf97        | rgba(111, 207, 151, 1) |
     | #56ccf2        | rgba(86, 204, 242, 1)  |
     | #bb6bd9        | rgba(187, 107, 217, 1) |
    - If the background color matches with the corresponding button text hexcode, then print "Button Color \<button color\> Matched"
    - Else, print "Button Color \<button color\> Mismatched"
- Click on each color button and test the page as below,

   <details>
   <summary>Click the `#e0e0e0` button</summary>
     - Verify the background color of the page and selected color text.
      - Page Background Color
        - Expected Background Color: `rgba(224, 224, 224, 1)`
        - If the actual background color and expected background color are the same, then print "Page Color \<button color\> Matched".
        - Else, print "Page Color \<button color\> Mismatched"
      - Selected Color Text (`<span>` element)
        - Expected Text: `#e0e0e0`
        - If the actual text and expected text are the same, then print "Selected Color Text \<button color\> Matched".
        - Else, print "Selected Color Text \<button color\> Mismatched"
    </details>
    <details>
   <summary>Click the `#6fcf97` button</summary>
     - Verify the background color of the page and selected color text.
      - Page Background Color
        - Expected Background Color: `rgba(111, 207, 151, 1)`
        - If the actual background color and expected background color are the same, then print "Page Color \<button color\> Matched".
        - Else, print "Page Color \<button color\> Mismatched"
      - Selected Color Text (`<span>` element)
        - Expected Text: `#6fcf97`
        - If the actual text and expected text are the same, then print "Selected Color Text \<button color\> Matched".
        - Else, print "Selected Color Text \<button color\> Mismatched"
    </details>
    <details>
   <summary>Click the `#56ccf2` button</summary>
     - Verify the background color of the page and selected color text.
      - Page Background Color
        - Expected Background Color: `rgba(86, 204, 242, 1)`
        - If the actual background color and expected background color are the same, then print "Page Color \<button color\> Matched".
        - Else, print "Page Color \<button color\> Mismatched"
      - Selected Color Text (`<span>` element)
        - Expected Text: `#56ccf2`
        - If the actual text and expected text are the same, then print "Selected Color Text \<button color\> Matched".
        - Else, print "Selected Color Text \<button color\> Mismatched"
    </details>
    <details>
   <summary>Click the `#bb6bd9` button</summary>
     - Verify the background color of the page and selected color text.
      - Page Background Color
        - Expected Background Color: `rgba(187, 107, 217, 1)`
        - If the actual background color and expected background color are the same, then print "Page Color \<button color\> Matched".
        - Else, print "Page Color \<button color\> Mismatched"
      - Selected Color Text (`<span>` element)
        - Expected Text: `#bb6bd9`
        - If the actual text and expected text are the same, then print "Selected Color Text \<button color\> Matched".
        - Else, print "Selected Color Text \<button color\> Mismatched"
    </details>

- Close the browser window.

<br>
<br>

**Note: Set up the project and practice this exercise in your local IDE(IntelliJ).**