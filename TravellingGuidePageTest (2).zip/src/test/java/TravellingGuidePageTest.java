import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TravellingGuidePageTest {
    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver", "PATH_TO_CHROMEDRIVER");

        WebDriver driver = new ChromeDriver();

        driver.get("https://qatravelguide.ccbp.tech/");

        WebElement varanasiElement = driver.findElement(By.id("varanasi"));
        varanasiElement.click();

        driver.switchTo().frame("frame");

        WebElement descriptionTextElement = driver.findElement(By.id("aboutTabContent"));
        System.out.println(descriptionTextElement.getText());

        WebElement timeToVisitButton = driver.findElement(By.id("timeToVisitButton"));
        timeToVisitButton.click();

        descriptionTextElement = driver.findElement(By.id("timeToVisitTabContent"));
        System.out.println(descriptionTextElement.getText());

        WebElement attractionsButton = driver.findElement(By.id("attractionsButton"));
        attractionsButton.click();

        descriptionTextElement = driver.findElement(By.id("attractionsTabContent"));
        System.out.println(descriptionTextElement.getText());

        driver.quit();
    }
}